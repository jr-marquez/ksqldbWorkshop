var gh = require('./geohash.js');

console.log(gh);

console.log("foo");
console.log(gh.geohash.decode_bbox('dp3wjh76'));

